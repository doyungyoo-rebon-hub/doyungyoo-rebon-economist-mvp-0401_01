# 하이브리드 GraphRAG 구축을 위한 금융 온톨로지 스키마 설계안
## (Financial Research Ontology Schema Specification for GraphRAG v1.8.4)

---

## 1. 개요 및 설계 목적 (Executive Summary)

본 문서는 **2025년 11월 1일부터 2026년 10월 30일 장 마감까지** 수집된 국내 29개 증권사(24개 공식 대상사 + 5개 시상제외사)의 **9,518건 리서치 리포트**와 **343명의 애널리스트**, 그리고 **금융감독원 전자공시(DART) 실제 실물 데이터** 간의 의미론적 관계(Semantic Relationship)를 정의하는 **온톨로지(Ontology) 스키마 표준 설계안**입니다.

하이브리드 GraphRAG는 전통적인 텍스트 청크 단위의 벡터 검색(Dense Vector Search)만으로는 해결하기 어려운 **"다단계 공급망 인과 추론(Multi-hop Traversal)"**, **"애널리스트 예측 편향(Bias) 역추적"**, **"DART 공시 실물 실적과의 엄밀한 팩트체크(Grounding)"**를 가능하게 합니다.

---

## 2. 온톨로지 전체 아키텍처 다이어그램 (ER & Triplet Diagram)

```
       ┌───────────────┐                  ┌────────────────┐
       │   Brokerage   │◄── EMPLOYED_BY ──│    Analyst     │
       │   (증권사 29개) │                  │   (연구원 343명) │
       └───────┬───────┘                  └───────┬────────┘
               │                                  │
          PUBLISHED_BY                         AUTHORED
               │                                  │
               ▼                                  ▼
       ┌──────────────────────────────────────────────────┐
       │                  ResearchReport                  │
       │                (리서치 리포트 9,518건)              │
       └─────┬──────────────────┬───────────────────┬─────┘
             │                  │                   │
         ANALYZES        CONTAINS_FORECAST      IDENTIFIES
             │                  │                   │
             ▼                  ▼                   ▼
    ┌────────────────┐  ┌───────────────┐   ┌────────────────┐
    │ Company / Stock│  │ForecastMetric │   │  CatalystRisk  │
    │  (상장 기업군)   │  │ (목표가/영업익) │   │ (투자논리/리스크)│
    └───┬────────┬───┘  └───────┬───────┘   └────────────────┘
        │        │              │
   SUPPLIES_TO   │      FACT_CHECKED_WITH
        │        │              │
        ▼        ▼              ▼
    ┌───────┐ ┌────────┐┌───────────────┐
    │Company│ │ Sector ││  DartFiling   │
    │(대장주)│ │ (10대) ││ (DART 분기공시)│
    └───────┘ └────────┘└───────────────┘
```

---

## 3. 핵심 엔티티 클래스 정의 (Core Entity Classes: 8대 클래스)

### 3.1 `Analyst` (애널리스트 / 연구원)
* **정의**: 리서치 리포트를 발간한 금융투자협회 공인 금융분석가 (전수 343명).
* **속성(Properties)**:
  - `analystId` (PK, string): 예) `"anl_kim_dongwon"`
  - `name` (string): 연구원 성명
  - `brokerId` (FK, string): 소속 증권사 ID
  - `primarySectorId` (FK, string): 주력 담당 섹터
  - `totalReportCount` (number): 기간 내 총 발간 편수 (총 9,518건 분배)
  - `weightedErrorRate` (number): 리본 가중 평균 오차율 (40% 비중 산출치)
  - `targetPriceAccuracy` (number): 목표주가 적중도 (30% 비중)
  - `dartAlignmentScore` (number): DART 공시 실적 정합률 (25% 비중)
  - `optimismBiasIndex` (number, 0~100): 시장 평균 대비 낙관 편향 점수
  - `analystTendency` (enum): `Conservative` | `Balanced` | `Contrarian` | `Aggressive`

### 3.2 `Brokerage` (증권사)
* **정의**: 리포트를 발간한 국내 증권사 (대상 24개사 + 시상제외 평가 5개사, 총 29개사).
* **속성(Properties)**:
  - `brokerId` (PK, string): 예) `"brk_kb"`, `"brk_shinhan"`
  - `brokerName` (string): 증권사 공식 명칭
  - `tierCategory` (enum): `OfficialTarget24` | `ExcludedReview5`
  - `totalAnalysts` (number): 소속 유효 연구원 수
  - `totalReports` (number): 누적 발간 편수
  - `houseAvgAccuracy` (number): 하우스 평균 KPI 점수

### 3.3 `ResearchReport` (리서치 리포트)
* **정의**: 발간된 정규 기업/산업 분석 보고서 (2025.11.01 ~ 2026.10.30 마감, 총 9,518건).
* **속성(Properties)**:
  - `reportId` (PK, string): 예) `"rep_9518_KB_001"`
  - `title` (string): 리포트 원제
  - `publishDate` (date): 발간 일자 (YYYY-MM-DD)
  - `analystId` (FK, string): 작성 애널리스트
  - `brokerId` (FK, string): 발행 증권사
  - `stockCode` (FK, string): 커버리지 종목 코드 (6자리)
  - `opinion` (enum): `Buy` | `Hold` | `Sell` | `NotRated`
  - `targetPrice` (number): 제시 목표주가 (원)
  - `currentPriceAtPublish` (number): 발간일 기준 시장 종가
  - `impliedUpside` (number): 목표 수익률 (%)
  - `pdfUrl` / `localPath` (string): 원문 문서 저장 경로
  - `vectorEmbeddingId` (string): 768차원 밀집 벡터 인덱스 키

### 3.4 `Company` (상장 기업)
* **정의**: KRX 상장 법인 및 리포트 커버리지 기업.
* **속성(Properties)**:
  - `stockCode` (PK, string): KRX 표준 종목코드 (예: `"000660"`, `"042700"`)
  - `companyName` (string): 기업명
  - `sectorId` (FK, string): 10대 표준 산업분류 ID
  - `marketType` (enum): `KOSPI` | `KOSDAQ`
  - `marketCap` (number): 시가총액 (억원 단위)
  - `hbmSupplyTier` (enum): `None` | `Tier1_Core` | `Tier2_Component` | `DeviceMaker`

### 3.5 `IndustrySector` (산업 섹터)
* **정의**: 표준 10대 산업 분류군.
* **속성(Properties)**:
  - `sectorId` (PK, string): 예) `"SEC_SEMI"`, `"SEC_BATTERY"`, `"SEC_BIO"`
  - `sectorName` (string): 섹터 한글명
  - `marketCapWeight` (number): 코스피/코스닥 시장 내 시총 비중 (%)
  - `sectorTotalReports` (number): 기간 내 섹터별 발간 총 편수

### 3.6 `ForecastMetric` (실적 추정치)
* **정의**: 리포트 본문에 기재된 분기별/연간 손익 추정치.
* **속성(Properties)**:
  - `forecastId` (PK, string): 예) `"fc_9518_001_2026Q3"`
  - `reportId` (FK, string): 출처 리포트 ID
  - `fiscalPeriod` (string): 추정 대상 분기 (예: `"2026Q1"`, `"2026Q2"`, `"2026Q3"`)
  - `estRevenue` (number): 추정 매출액 (억원)
  - `estOpProfit` (number): 추정 영업이익 (억원, 오차율 60% 비중 핵심 지표)
  - `estNetIncome` (number): 추정 당기순이익 (억원)

### 3.7 `DartFiling` (DART 전자공시 실적)
* **정의**: 금융감독원 전자공시시스템(DART)에 공시된 실제 분기/반기/사업보고서 팩트.
* **속성(Properties)**:
  - `receiptNo` (PK, string): 14자리 공시 접수번호 (예: `"20261028000412"`)
  - `stockCode` (FK, string): 대상 기업 코드
  - `filingDate` (date): 공시 제출일
  - `fiscalPeriod` (string): 해당 분기
  - `actualRevenue` (number): 실제 공시 매출액
  - `actualOpProfit` (number): 실제 공시 영업이익
  - `actualNetIncome` (number): 실제 공시 당기순이익
  - `varianceOpProfit` (number): 컨센서스 대비 실제 어닝 서프라이즈/쇼크 괴리율 (%)

### 3.8 `CatalystRisk` (투자 논리 및 리스크 팩터)
* **정의**: 리포트 본문에서 추출된 핵심 촉매(Catalyst)와 하방 위험(Risk) 요인.
* **속성(Properties)**:
  - `factorId` (PK, string): 예) `"risk_hbm_chasm"`, `"cat_biosecure"`
  - `factorType` (enum): `CATALYST` (상방 모멘텀) | `RISK` (하방 위험)
  - `category` (string): `기술경쟁`, `수주`, `매크로/환율`, `규제`, `원자재`
  - `keywordSummary` (string): 추출 핵심 문구
  - `sentimentScore` (number, -1.0 ~ +1.0): 텍스트 감성 극성 지수

---

## 4. 관계 명세 (Relationships / Directed Edges: 12대 관계)

| 관계명 (Edge Type) | 시작 노드 (Source) | 도착 노드 (Target) | 다중도 (Cardinality) | 설명 및 메타데이터 (Attributes) |
|---|---|---|---|---|
| **AUTHORED** | `Analyst` | `ResearchReport` | `1 : N` | 연구원이 작성한 리포트 연결 (가중치: 1.0) |
| **EMPLOYED_BY** | `Analyst` | `Brokerage` | `N : 1` | 연구원의 소속 증권사 (재직 상태, 퇴사 여부) |
| **ANALYZES** | `ResearchReport` | `Company` | `N : 1` | 리포트의 주요 분석 대상 종목 |
| **COVERS** | `Analyst` | `Company` | `N : M` | 연구원의 정기 커버리지 유니버스 |
| **BELONGS_TO** | `Company` | `IndustrySector`| `N : 1` | 기업의 소속 10대 표준 산업군 |
| **CONTAINS_FORECAST** | `ResearchReport`| `ForecastMetric`| `1 : N` | 분기별 실적 추정치 연결 |
| **FACT_CHECKED_WITH** | `ForecastMetric`| `DartFiling` | `1 : 1` | 추정치 ↔ 실제 DART 공시 실적 매핑 (오차율 `%` 저장) |
| **SUPPLIES_TO** | `Company` | `Company` | `N : M` | 공급망 밸류체인 관계 (예: 한미반도체 → SK하이닉스, 납품 품목) |
| **COMPETES_WITH** | `Company` | `Company` | `N : M` | 동종 업계 경쟁 관계 (예: SK하이닉스 ↔ 삼성전자) |
| **IDENTIFIES** | `ResearchReport` | `CatalystRisk` | `N : M` | 리포트 내 제시된 핵심 투자 포인트 및 리스크 |
| **EXPOSES_RISK** | `IndustrySector`| `CatalystRisk` | `N : M` | 특정 산업군 전체가 직면한 거시적 리스크 |
| **CORRELATES_PRICE** | `ResearchReport`| `MarketPrice` | `1 : N` | 발간 후 30/60/90일 실제 주가 경로 추적 (적중도 `%`) |

---

## 5. 지식 그래프 트리플렛 예시 (Knowledge Graph Triplet Examples)

### 예시 1: AI 반도체 HBM 밸류체인 추론 경로
```cypher
(:Analyst {name: "김동원", broker: "KB증권"})
  -[:AUTHORED]-> (:ResearchReport {reportId: "rep_9518_KB_001", targetPrice: 280000})
  -[:ANALYZES]-> (:Company {name: "SK하이닉스", code: "000660"})
  <-[:SUPPLIES_TO {product: "Dual TC Bonder"}]- (:Company {name: "한미반도체", code: "042700"})
  -[:FACT_CHECKED_WITH {errorRate: 0.99}]-> (:DartFiling {receiptNo: "20261028000412", opProfit: 70300})
```

### 예시 2: 2차전지 캐즘 선제 하향 및 역발상 리포트 경로
```cypher
(:Analyst {name: "정원석", tendency: "Contrarian"})
  -[:AUTHORED]-> (:ResearchReport {opinion: "Hold", targetPrice: 420000})
  -[:IDENTIFIES]-> (:CatalystRisk {factorType: "RISK", keyword: "유럽 배터리 법인 가동률 급락"})
  -[:ANALYZES]-> (:Company {name: "LG에너지솔루션", code: "373220"})
  -[:FACT_CHECKED_WITH {alignmentScore: 99.1}]-> (:DartFiling {filingDate: "2026-08-14"})
```

---

## 6. 하이브리드 GraphRAG 질의 처리 아키텍처 (Query Traversal Flow)

GraphRAG 검색 엔진은 입력된 자연어 질의에 대해 **2단계 파이프라인**으로 작동합니다:

1. **1단계: 지식 그래프 경로 탐색 (Graph Traversal)**
   - 사용자 질의에서 엔티티(기업명, 연구원명, 섹터)를 추출하고 온톨로지에서 1~2 홉 이내의 서브그래프를 BFS 방식으로 전개합니다.
   - 예: "SK하이닉스 장비 공급사 중 실적 적중도가 높은 곳은?"
     → `(SK하이닉스) <-[:SUPPLIES_TO]- (장비사들: 한미반도체, HPSP) <-[:COVERS]- (애널리스트) -[:FACT_CHECKED_WITH]- (DART 공시)`

2. **2단계: 밀집 벡터 검색(Dense Vector Retrieval)과의 하이브리드 융합**
   - 탐색된 서브그래프 노드들의 고유 ID(`reportId`, `receiptNo`)를 필터로 설정하여, 9,518건 리포트 벡터 인덱스에서 가장 의미적 유사도가 높은 문단을 Top-K로 추출합니다.
   - 그래프 메타데이터(수치/오차율 팩트) + 벡터 텍스트(논리 문단)를 합쳐 **Gemini 3.8 Flash**의 프롬프트 컨텍스트로 제공합니다.

---

## 7. 기대 효과 및 시스템 구현 연계 방안

1. **환각(Hallucination) 원천 차단**:
   - DART 전자공시 접수번호(`receiptNo`)와 리포트 원문 번호(`reportId`)가 온톨로지 엣지로 고정 연결되어 있어 인용 출처가 명백합니다.
2. **복합 인과관계 추론**:
   - "A기업의 수주 공시가 지연되었을 때 공급망 B기업의 실적을 가장 정확하게 예측한 연구원"과 같은 3단 다중 홉(Multi-hop) 질문에 즉각적인 해답을 도출합니다.
3. **현재 애플리케이션(v1.8.4)과의 정합성**:
   - 이미 대시보드 내 구축된 `awardsData.ts`(343명 평가치), `koreanStocks.ts`(상장 종목), `DartFactCheck.tsx`(DART 정합도 99.8%) 및 신규 추가된 `ResearchIntelligence01.tsx`와 100% 동일한 필드 규격을 공유합니다.
